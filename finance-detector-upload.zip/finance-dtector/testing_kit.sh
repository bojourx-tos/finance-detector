#!/bin/bash

# HP Finance Detector Testing Kit
echo "🧪 HP Finance Detector Testing Kit"

# Function to test USB connection
test_usb_connection() {
    echo "🔌 Testing USB connection..."
    
    # Check if ADB is available
    if ! command -v adb &> /dev/null; then
        echo "❌ ADB not found! Install Android SDK Platform Tools"
        return 1
    fi
    
    # List connected devices
    devices=$(adb devices | grep -v "List of devices" | grep "device$" | wc -l)
    
    if [ $devices -eq 0 ]; then
        echo "❌ No devices connected via USB"
        echo "💡 Make sure:"
        echo "   - USB debugging is enabled"
        echo "   - Device is connected via USB"
        echo "   - Trust computer dialog accepted"
        return 1
    elif [ $devices -eq 1 ]; then
        echo "⚠️  Only 1 device connected"
        echo "💡 Connect HP target for testing"
        return 1
    else
        echo "✅ Multiple devices connected - Ready for testing!"
        adb devices
        return 0
    fi
}

# Function to install test finance apps (for testing purposes)
install_test_apps() {
    echo "📱 Installing test finance apps..."
    
    # Create dummy finance app packages for testing
    echo "Creating test packages..."
    
    # This would install actual finance apps for testing
    # WARNING: Only use for testing purposes!
    echo "⚠️  Install real finance apps manually for accurate testing"
    echo "Recommended test apps:"
    echo "- Akulaku (from Play Store)"
    echo "- Kredivo (from Play Store)" 
    echo "- Any pinjol app for validation"
}

# Function to run comprehensive test
run_comprehensive_test() {
    echo "🎯 Running comprehensive test..."
    
    echo "Test 1: Clean device (should be SAFE)"
    echo "Test 2: Device with finance apps (should be DANGER)"
    echo "Test 3: Device with hidden apps (should detect traces)"
    
    # Install and run the detector app
    if [ -f "HPFinanceDetector.apk" ]; then
        echo "📲 Installing HP Finance Detector..."
        adb install -r HPFinanceDetector.apk
        
        echo "🚀 Launching app..."
        adb shell am start -n com.hpdetector.finance/.MainActivity
        
        echo "✅ App launched! Perform manual testing now."
    else
        echo "❌ HPFinanceDetector.apk not found!"
        echo "Run ./build.sh first to build the APK"
    fi
}

# Function to validate results
validate_results() {
    echo "📊 Result validation checklist:"
    echo ""
    echo "✅ Expected Results:"
    echo "   Clean HP: Risk Score 0-19, Status SAFE"
    echo "   Finance HP: Risk Score 80-100, Status DANGER"
    echo "   Suspicious HP: Risk Score 20-79, Status WARNING/CAUTION"
    echo ""
    echo "✅ UI Validation:"
    echo "   - Risk score displays correctly"
    echo "   - App list shows detected finance apps"
    echo "   - Recommendation is clear and actionable"
    echo "   - Colors match risk level (Red=Danger, Green=Safe)"
    echo ""
    echo "✅ Performance Validation:"
    echo "   - Scan completes within 10 seconds"
    echo "   - No crashes or errors"
    echo "   - USB connection stable"
    echo "   - Results are consistent on re-scan"
}

# Main menu
echo "Select testing option:"
echo "1. Test USB Connection"
echo "2. Install Test Apps"
echo "3. Run Comprehensive Test"
echo "4. Validate Results"
echo "5. All Tests"

read -p "Enter choice (1-5): " choice

case $choice in
    1) test_usb_connection ;;
    2) install_test_apps ;;
    3) run_comprehensive_test ;;
    4) validate_results ;;
    5) 
        test_usb_connection
        install_test_apps  
        run_comprehensive_test
        validate_results
        ;;
    *) echo "Invalid choice" ;;
esac

echo ""
echo "🎯 Testing complete!"
echo "📋 Document all results for validation"