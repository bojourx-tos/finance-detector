# Panduan Testing HP Finance Detector

## ⚠️ PENTING - VALIDASI FUNGSIONALITAS

### 1. Persiapan Testing

**HP Detector (yang install aplikasi):**
- Android 7.0+ 
- USB OTG support
- Install APK HP Finance Detector

**HP Target (yang mau dicek):**
- Enable Developer Options
- Enable USB Debugging
- Kabel USB OTG

### 2. Skenario Testing

**Test Case 1: HP Bersih (AMAN)**
```
Expected: ✅ AMAN - Tidak ada aplikasi finance
Result: Rekomendasi AMAN UNTUK DIBELI
```

**Test Case 2: HP Ada Finance App (BAHAYA)**
```
Expected: ⚠️ BAHAYA - Ditemukan X aplikasi finance
Result: Rekomendasi JANGAN BELI!
Apps: Akulaku, Kredivo, dll
```

### 3. Aplikasi Finance yang Dideteksi

**Pinjol Populer:**
- Akulaku (com.akulaku.user)
- Kredivo (com.kredivo.user) 
- Home Credit (com.homecredit.mobile)
- Indodana (com.indodana.app)
- Tunaiku (com.tunaiku.mobile)
- Kredit Pintar (com.kredit.pintar)
- Julo (com.julo.app)
- AdaKami (com.adakami.app)

**Bank Digital:**
- Modalku (com.modalku.app)
- Danamas (com.danamas.app)
- KTA Kilat (com.kta.kilat)

### 4. Validasi Akurasi

**False Positive Check:**
- Pastikan tidak salah deteksi app banking normal
- Cek hanya app finance/pinjol yang terdeteksi

**False Negative Check:**
- Test dengan HP yang pasti ada app pinjol
- Pastikan semua app finance terdeteksi

### 5. Real World Testing

**Scenario A: Toko HP Bekas**
1. Test 10 HP bekas random
2. Catat hasil deteksi
3. Validasi dengan pemilik sebelumnya

**Scenario B: HP Finance Aktif**
1. Test HP yang pasti masih kredit
2. Harus detect sebagai BAHAYA
3. List semua app yang ditemukan

### 6. Keamanan & Legal

**Disclaimer Wajib:**
- Aplikasi untuk screening awal saja
- Tidak 100% akurat
- Tetap cek dokumen resmi
- Gunakan sesuai hukum yang berlaku

### 7. Reporting Bug

Jika menemukan masalah:
- Screenshot hasil scan
- Model HP yang ditest
- List app yang seharusnya terdeteksi
- Hasil actual vs expected

**TUJUAN: Melindungi masyarakat dari penipuan HP bekas yang masih dalam kredit!**