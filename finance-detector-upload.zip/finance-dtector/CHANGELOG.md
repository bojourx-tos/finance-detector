# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial open source release
- Comprehensive documentation
- GitHub issue and PR templates
- Security policy
- Contributing guidelines

## [1.0.0] - 2024-01-XX

### Added
- Finance application detection for major Indonesian lending apps
- IMEI status checking functionality
- System analysis for monitoring app traces
- Audio feedback system with enhanced sound management
- App uninstall functionality (requires root)
- Professional UI with modern design
- USB debugging support
- Root access utilities

### Security
- Local-only data processing
- No external data transmission
- Secure permission handling

### Supported Finance Apps
- Akulaku
- Kredivo
- Home Credit
- Indodana
- EasyCash
- CashCash

[Unreleased]: https://github.com/yourusername/finance-detector/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/yourusername/finance-detector/releases/tag/v1.0.0