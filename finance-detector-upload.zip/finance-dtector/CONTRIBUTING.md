# Contributing to HP Finance Detector

Thank you for your interest in contributing to HP Finance Detector! This document provides guidelines for contributing to the project.

## Code of Conduct

This project is intended for educational and consumer protection purposes. Please ensure all contributions align with these goals and comply with applicable laws.

## How to Contribute

### Reporting Issues

1. Check existing issues before creating a new one
2. Use clear, descriptive titles
3. Include steps to reproduce the issue
4. Provide device information and Android version

### Submitting Changes

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-detection`)
3. Make your changes
4. Test thoroughly on different Android versions
5. Commit with clear messages
6. Push to your fork
7. Submit a pull request

### Development Guidelines

- Follow Android development best practices
- Maintain compatibility with Android API 21+
- Add comments for complex detection logic
- Test on multiple devices and Android versions
- Ensure no sensitive data is logged

### Adding New Finance App Detection

1. Add app package name to detection list
2. Include app signature verification if possible
3. Test detection accuracy
4. Update documentation

## Legal Considerations

- Only detect publicly available app information
- Respect user privacy and data protection laws
- Do not include methods that could be used maliciously
- Ensure compliance with local regulations

## Questions?

Open an issue for questions about contributing or contact the maintainers.