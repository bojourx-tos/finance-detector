# 🚀 SETUP GUIDE - HP FINANCE DETECTOR

## 📱 PERSIAPAN HP DETECTOR

### Step 1: Install APK
```bash
# Build APK dari source code
./gradlew assembleRelease

# Atau download APK yang sudah jadi
# Install via ADB atau langsung di HP
adb install HPFinanceDetector.apk
```

### Step 2: Enable Permissions
- ✅ Storage Access
- ✅ USB Permission  
- ✅ Device Admin (optional)
- ✅ Install from Unknown Sources

### Step 3: Test USB OTG
- Colok flashdisk ke HP detector
- Pastikan terdeteksi di file manager
- Jika tidak terdeteksi = HP tidak support OTG

## 🔧 PERSIAPAN HP TARGET

### Step 1: Enable Developer Options
```
Settings → About Phone → Tap "Build Number" 7x
```

### Step 2: Enable USB Debugging
```
Settings → Developer Options → USB Debugging = ON
```

### Step 3: Set USB Mode
```
Developer Options → Default USB Configuration = "File Transfer"
```

## 🔌 KONEKSI SETUP

### Method 1: USB OTG (Recommended)
```
HP Detector ←--[USB OTG]--→ HP Target
```

### Method 2: ADB Wireless (Advanced)
```bash
# Di HP target
adb tcpip 5555
adb connect [IP_HP_TARGET]:5555

# Di HP detector (perlu ADB tools)
adb devices
```

## ⚡ OPTIMASI PERFORMA

### 1. Disable Antivirus Sementara
- Beberapa antivirus block package scanning
- Whitelist aplikasi HP Finance Detector

### 2. Close Background Apps
- Tutup aplikasi lain saat scanning
- Free up RAM untuk proses optimal

### 3. Stable Power Supply
- Charge HP detector minimal 50%
- Gunakan power bank jika perlu

## 🎯 TESTING CHECKLIST

### Pre-Scan Validation:
- [ ] USB OTG cable connected
- [ ] HP target USB debugging ON
- [ ] HP detector has permissions
- [ ] Both devices charged >50%

### During Scan:
- [ ] Connection stable (no disconnect)
- [ ] Scan progress showing
- [ ] No error messages
- [ ] Results displaying properly

### Post-Scan Validation:
- [ ] Risk score calculated
- [ ] Apps list accurate
- [ ] Recommendation clear
- [ ] Screenshot for documentation

## 🚨 TROUBLESHOOTING

### "USB Device Not Detected"
```
Solution:
1. Check USB OTG cable
2. Try different USB port
3. Restart both devices
4. Re-enable USB debugging
```

### "Permission Denied"
```
Solution:
1. Grant all app permissions
2. Allow USB debugging popup
3. Trust computer dialog = YES
4. Disable USB verification
```

### "Scan Failed/Incomplete"
```
Solution:
1. Close other apps
2. Clear app cache
3. Restart scan process
4. Check available storage
```

### "False Results"
```
Solution:
1. Update app database
2. Clear system cache
3. Verify HP target is unlocked
4. Check for hidden apps manually
```

## 📊 USAGE BEST PRACTICES

### For Toko HP:
- Scan semua HP sebelum beli
- Dokumentasi hasil scan
- Edukasi customer tentang risiko
- Jangan beli HP dengan risk score >50

### For Individual Buyer:
- Minta ijin penjual untuk scan
- Explain tujuan untuk keamanan
- Screenshot hasil sebagai bukti
- Nego harga jika ada risk detected

### For Bulk Testing:
- Siapkan multiple USB cables
- Batch scan 5-10 HP per session
- Log semua hasil untuk analisis
- Update database secara berkala

## 🔄 MAINTENANCE

### Weekly:
- Update finance app database
- Clear app cache
- Check for app updates

### Monthly:  
- Validate detection accuracy
- Add new finance apps
- Review false positive cases
- Backup scan results

**TARGET: 95%+ akurasi deteksi untuk melindungi masyarakat!**