#!/bin/bash

# HP Finance Detector Build Script
echo "🚀 Building HP Finance Detector APK..."

# Check if Android SDK is installed
if [ ! -d "$ANDROID_HOME" ]; then
    echo "❌ Android SDK not found!"
    echo "Install Android Studio or set ANDROID_HOME"
    exit 1
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build debug APK for testing
echo "🔨 Building debug APK..."
./gradlew assembleDebug

# Build release APK for production
echo "📦 Building release APK..."
./gradlew assembleRelease

# Check if build successful
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    echo "✅ Build successful!"
    echo "📱 APK location: app/build/outputs/apk/release/app-release.apk"
    
    # Copy to easy access location
    cp app/build/outputs/apk/release/app-release.apk ./HPFinanceDetector.apk
    echo "📋 APK copied to: ./HPFinanceDetector.apk"
    
    # Show APK info
    echo "📊 APK Info:"
    ls -lh HPFinanceDetector.apk
    
else
    echo "❌ Build failed!"
    echo "Check gradle logs for errors"
    exit 1
fi

echo "🎉 Ready to install and test!"
echo "Install command: adb install HPFinanceDetector.apk"