# 🚀 QUICK START - HP Finance Detector

## ⚡ Instalasi Cepat Development Environment

### Step 1: Jalankan Setup Otomatis
```bash
cd /home/xtos/MI\ PROJEC/ultra/HPFinanceDetector
./setup_dev_environment.sh
```

### Step 2: Restart Terminal
```bash
# Restart terminal atau jalankan:
source ~/android-dev/android-env.sh
```

### Step 3: Setup Project
```bash
~/android-dev/setup_hp_detector_project.sh
```

### Step 4: Build APK
```bash
cd /home/xtos/MI\ PROJEC/ultra/HPFinanceDetector
./gradlew assembleDebug
```

## 🔧 Manual Setup (Jika Otomatis Gagal)

### Install Java 11
```bash
sudo apt update
sudo apt install openjdk-11-jdk
```

### Download Android Studio
```bash
# Linux
wget https://redirector.gvt1.com/edgedl/android/studio/ide-zips/2023.1.1.28/android-studio-2023.1.1.28-linux.tar.gz
tar -xzf android-studio-*-linux.tar.gz
```

### Setup Environment Variables
```bash
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools"
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk-amd64"
```

### Install SDK Packages
```bash
sdkmanager "platform-tools" "platforms;android-24" "platforms;android-33" "build-tools;33.0.2"
```

## 📱 Test Installation

### Check Tools
```bash
java -version          # Should show Java 11
adb version           # Should show ADB version
./gradlew --version   # Should show Gradle 8.0
```

### Build Test
```bash
./gradlew assembleDebug
# APK akan dibuat di: app/build/outputs/apk/debug/
```

## 🎯 Ready to Use!

Setelah setup berhasil:
1. ✅ Android Studio siap digunakan
2. ✅ SDK API 24+ terinstall
3. ✅ Java/Kotlin support aktif
4. ✅ ADB tools tersedia
5. ✅ Project siap di-build

**Total waktu setup: ~30 menit**
**APK siap melindungi masyarakat dari penipuan HP bekas!**