package com.hpdetector.finance;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class UninstallActivity extends Activity {
    
    private TextView titleText;
    private TextView statusText;
    private ListView financeAppsList;
    private Button uninstallAllButton;
    private Button uninstallSelectedButton;
    private Button guideButton;
    private Button backButton;
    
    private ArrayAdapter<String> adapter;
    private UninstallManager uninstallManager;
    private List<String> detectedPackages;
    private List<String> detectedAppNames;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uninstall);
        
        initializeViews();
        setupClickListeners();
        
        uninstallManager = new UninstallManager(this);
        
        // Setup list adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        financeAppsList.setAdapter(adapter);
        
        // Start scanning for finance apps
        new ScanFinanceAppsTask().execute();
    }
    
    private void initializeViews() {
        titleText = findViewById(R.id.titleText);
        statusText = findViewById(R.id.statusText);
        financeAppsList = findViewById(R.id.financeAppsList);
        uninstallAllButton = findViewById(R.id.uninstallAllButton);
        uninstallSelectedButton = findViewById(R.id.uninstallSelectedButton);
        guideButton = findViewById(R.id.guideButton);
        backButton = findViewById(R.id.backButton);
    }
    
    private void setupClickListeners() {
        uninstallAllButton.setOnClickListener(v -> {
            if (detectedPackages != null && !detectedPackages.isEmpty()) {
                uninstallManager.showUninstallOptions(detectedPackages, detectedAppNames);
            } else {
                Toast.makeText(this, "Tidak ada aplikasi finance yang terdeteksi", Toast.LENGTH_SHORT).show();
            }
        });
        
        uninstallSelectedButton.setOnClickListener(v -> {
            if (detectedPackages != null && !detectedPackages.isEmpty()) {
                showSelectiveUninstallDialog();
            } else {
                Toast.makeText(this, "Tidak ada aplikasi finance yang terdeteksi", Toast.LENGTH_SHORT).show();
            }
        });
        
        guideButton.setOnClickListener(v -> {
            uninstallManager.showUninstallGuide();
        });
        
        backButton.setOnClickListener(v -> {
            finish();
        });
    }
    
    private class ScanFinanceAppsTask extends AsyncTask<Void, String, SimpleDetector.ScanResult> {
        
        @Override
        protected void onPreExecute() {
            statusText.setText("[KNIFE] Berburu aplikasi finance berbahaya...");
            adapter.add("[SKULL] Memulai mode pembunuh...");
            adapter.add("[KNIFE] Mengintai aplikasi terinstall...");
            
            // Disable buttons during scan
            uninstallAllButton.setEnabled(false);
            uninstallSelectedButton.setEnabled(false);
        }
        
        @Override
        protected SimpleDetector.ScanResult doInBackground(Void... params) {
            try {
                publishProgress("[SEARCH] Mengintai package manager...");
                Thread.sleep(1000);
                
                publishProgress("[KNIFE] Menganalisis target finance...");
                Thread.sleep(1500);
                
                SimpleDetector detector = new SimpleDetector(UninstallActivity.this);
                return detector.performScan();
                
            } catch (Exception e) {
                SimpleDetector.ScanResult errorResult = new SimpleDetector.ScanResult();
                errorResult.status = "ERROR";
                errorResult.message = "Scan error: " + e.getMessage();
                return errorResult;
            }
        }
        
        @Override
        protected void onProgressUpdate(String... progress) {
            adapter.add(progress[0]);
        }
        
        @Override
        protected void onPostExecute(SimpleDetector.ScanResult result) {
            adapter.clear();
            
            detectedPackages = result.detectedPackages;
            detectedAppNames = result.detectedApps;
            
            if (!result.detectedApps.isEmpty()) {
                statusText.setText("💀 DITEMUKAN " + result.detectedApps.size() + " TARGET FINANCE! 💀");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                
                adapter.add("💀 TARGET BERHASIL DITEMUKAN:");
                adapter.add("");
                
                for (int i = 0; i < result.detectedApps.size(); i++) {
                    adapter.add("• " + result.detectedApps.get(i));
                    adapter.add("  Package: " + result.detectedPackages.get(i));
                    adapter.add("");
                }
                
                adapter.add("☠️ PERINGATAN MEMATIKAN:");
                adapter.add("🩸 Aplikasi ini MENGINFEKSI HP dengan hutang!");
                adapter.add("");
                adapter.add("🔪 RENCANA EKSEKUSI:");
                adapter.add("💀 BUNUH aplikasi ini untuk keamanan data pribadi");
                
                // Enable uninstall buttons
                uninstallAllButton.setEnabled(true);
                uninstallSelectedButton.setEnabled(true);
                uninstallAllButton.setVisibility(View.VISIBLE);
                uninstallSelectedButton.setVisibility(View.VISIBLE);
                
            } else {
                statusText.setText("✅ TIDAK ADA APLIKASI FINANCE");
                statusText.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                
                adapter.add("✅ HASIL SCAN:");
                adapter.add("");
                adapter.add("Tidak ditemukan aplikasi finance yang mencurigakan");
                adapter.add("");
                adapter.add("📱 HP ini relatif aman dari aplikasi kredit");
                adapter.add("");
                adapter.add("💡 CATATAN:");
                adapter.add("Tetap periksa dokumen pembelian resmi");
                
                // Hide uninstall buttons
                uninstallAllButton.setVisibility(View.GONE);
                uninstallSelectedButton.setVisibility(View.GONE);
            }
        }
    }
    
    private void showSelectiveUninstallDialog() {
        if (detectedAppNames == null || detectedAppNames.isEmpty()) {
            Toast.makeText(this, "Tidak ada aplikasi finance yang terdeteksi", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String[] appArray = detectedAppNames.toArray(new String[0]);
        boolean[] checkedItems = new boolean[appArray.length];
        
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Pilih Aplikasi untuk Dihapus");
        
        builder.setMultiChoiceItems(appArray, checkedItems, (dialog, which, isChecked) -> {
            checkedItems[which] = isChecked;
        });
        
        builder.setPositiveButton("HAPUS TERPILIH", (dialog, which) -> {
            List<String> selectedPackages = new ArrayList<>();
            List<String> selectedNames = new ArrayList<>();
            
            for (int i = 0; i < checkedItems.length; i++) {
                if (checkedItems[i]) {
                    selectedPackages.add(detectedPackages.get(i));
                    selectedNames.add(detectedAppNames.get(i));
                }
            }
            
            if (!selectedPackages.isEmpty()) {
                uninstallManager.showUninstallOptions(selectedPackages, selectedNames);
            } else {
                Toast.makeText(this, "Tidak ada aplikasi yang dipilih", Toast.LENGTH_SHORT).show();
            }
        });
        
        builder.setNegativeButton("BATAL", null);
        
        android.app.AlertDialog dialog = builder.create();
        dialog.show();
    }
}