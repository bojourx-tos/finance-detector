# Installation Guide

## Prerequisites

- Android Studio 4.0 or higher
- Android SDK with API level 21+
- Java 8 or higher
- Git

## Development Setup

### 1. Clone Repository

```bash
git clone https://github.com/yourusername/finance-detector.git
cd finance-detector
```

### 2. Open in Android Studio

1. Launch Android Studio
2. Select "Open an existing Android Studio project"
3. Navigate to the cloned directory
4. Wait for Gradle sync to complete

### 3. Build Project

```bash
# Debug build
./gradlew assembleDebug

# Release build (requires signing)
./gradlew assembleRelease
```

## Device Installation

### Method 1: ADB Install

```bash
# Enable USB debugging on your device
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Method 2: Direct APK Install

1. Transfer APK to device
2. Enable "Unknown sources" in Settings
3. Install APK file

## Permissions Setup

The app requires several permissions:

### Required Permissions
- USB Permission - For device connection
- Query All Packages - For app detection
- Internet - For future online features
- Read Phone State - For IMEI access

### Optional Permissions (Root)
- Delete Packages - For app removal
- Write Secure Settings - For system modifications

## Troubleshooting

### Build Issues

**Gradle sync failed:**
```bash
./gradlew clean
./gradlew build
```

**Missing SDK:**
- Install required SDK versions in Android Studio
- Update local.properties with correct SDK path

### Runtime Issues

**USB debugging not working:**
- Enable Developer Options
- Enable USB Debugging
- Accept RSA key fingerprint

**Permission denied:**
- Grant all requested permissions
- For root features, ensure device is rooted

## Testing

### Unit Tests
```bash
./gradlew test
```

### Instrumented Tests
```bash
./gradlew connectedAndroidTest
```

### Manual Testing Checklist

- [ ] App launches successfully
- [ ] USB connection detected
- [ ] Finance apps detected correctly
- [ ] No false positives
- [ ] Audio feedback works
- [ ] Root features (if applicable)

## Release Build

For production releases:

1. Generate signed APK in Android Studio
2. Use release keystore
3. Enable ProGuard/R8 obfuscation
4. Test thoroughly on multiple devices