# API Documentation

## Core Classes

### SimpleDetector

Main detection engine for finance applications.

```java
public class SimpleDetector {
    public List<String> scanInstalledApps(Context context)
    public boolean isFinanceApp(String packageName)
    public int calculateRiskScore(List<String> detectedApps)
}
```

### UninstallManager

Handles application removal functionality.

```java
public class UninstallManager {
    public boolean uninstallApp(String packageName)
    public boolean requiresRoot()
    public List<String> getUninstallableApps()
}
```

### RootUtils

Root access utilities and system-level operations.

```java
public class RootUtils {
    public static boolean isRootAvailable()
    public static boolean executeRootCommand(String command)
    public static boolean hasRootPermission()
}
```

### EnhancedSoundManager

Audio feedback system for detection results.

```java
public class EnhancedSoundManager {
    public void playDetectionSound(DetectionResult result)
    public void playWarningSound()
    public void setVolumeLevel(float level)
}
```

## Detection Methods

### Package Name Detection

Primary method for identifying finance applications:

```java
private static final String[] FINANCE_PACKAGES = {
    "com.akulaku.user",
    "com.kredivo.app", 
    "com.homecredit.myapplication",
    "com.indodana.app",
    "com.easycash.app",
    "com.cashcash.mobile"
};
```

### System Analysis

Advanced detection methods:

- Application signature verification
- File system trace analysis
- Process monitoring detection
- Network activity analysis

## Events and Callbacks

### ScanListener

Interface for scan progress and results:

```java
public interface ScanListener {
    void onScanStarted();
    void onAppDetected(String packageName, String appName);
    void onScanProgress(int progress);
    void onScanCompleted(ScanResult result);
    void onScanError(Exception error);
}
```

### DetectionResult

Result object containing scan information:

```java
public class DetectionResult {
    public List<String> detectedApps;
    public int riskScore;
    public long scanDuration;
    public boolean hasRootAccess;
    public Map<String, String> systemInfo;
}
```

## Configuration

### Detection Settings

```java
public class DetectionConfig {
    public boolean enableDeepScan = true;
    public boolean checkSystemApps = false;
    public boolean enableAudioFeedback = true;
    public int scanTimeout = 30000; // 30 seconds
}
```

### Audio Settings

```java
public class AudioConfig {
    public float warningVolume = 0.8f;
    public float successVolume = 0.5f;
    public boolean enableVibration = true;
    public int soundDuration = 2000; // 2 seconds
}
```

## Error Handling

### Common Exceptions

- `SecurityException` - Insufficient permissions
- `RootAccessException` - Root access required but not available
- `DeviceNotConnectedException` - USB device not connected
- `ScanTimeoutException` - Scan operation timed out

### Error Codes

```java
public static final int ERROR_NO_PERMISSION = 1001;
public static final int ERROR_NO_ROOT = 1002;
public static final int ERROR_USB_NOT_CONNECTED = 1003;
public static final int ERROR_SCAN_TIMEOUT = 1004;
public static final int ERROR_UNKNOWN = 9999;
```

## Usage Examples

### Basic Scan

```java
SimpleDetector detector = new SimpleDetector();
detector.setScanListener(new ScanListener() {
    @Override
    public void onScanCompleted(ScanResult result) {
        // Handle results
    }
});
detector.startScan(context);
```

### Root Operations

```java
if (RootUtils.isRootAvailable()) {
    UninstallManager manager = new UninstallManager();
    boolean success = manager.uninstallApp("com.akulaku.user");
}
```

### Audio Feedback

```java
EnhancedSoundManager soundManager = new EnhancedSoundManager(context);
soundManager.playDetectionSound(detectionResult);
```