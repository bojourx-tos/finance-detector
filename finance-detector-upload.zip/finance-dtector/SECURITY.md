# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability in HP Finance Detector, please report it responsibly:

1. **Do NOT** open a public issue
2. Email security concerns to the maintainers
3. Include detailed information about the vulnerability
4. Allow time for the issue to be addressed before public disclosure

## Security Considerations

### App Permissions

This app requires several sensitive permissions for its functionality:
- `QUERY_ALL_PACKAGES` - To scan installed applications
- `READ_PHONE_STATE` - To access device IMEI (where legally permitted)
- `USB_PERMISSION` - For USB debugging connections
- Root permissions - For advanced system-level detection

### Data Handling

- No personal data is transmitted to external servers
- IMEI information is processed locally only
- Scan results are stored locally on the device
- No user tracking or analytics

### Responsible Use

This tool is designed for:
- Consumer protection when buying used devices
- Educational purposes about mobile security
- Legitimate security research

This tool should NOT be used for:
- Unauthorized access to devices
- Violating privacy laws
- Malicious purposes

## Best Practices

1. Only use on devices you own or have explicit permission to scan
2. Comply with local laws regarding device scanning and privacy
3. Keep the app updated to the latest version
4. Use in conjunction with other verification methods

## Disclaimer

Users are responsible for ensuring their use of this application complies with applicable laws and regulations in their jurisdiction.