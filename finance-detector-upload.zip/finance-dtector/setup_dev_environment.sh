#!/bin/bash

# HP Finance Detector - Development Environment Setup
echo "🚀 Setting up Development Environment for HP Finance Detector"

# Check system
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    PLATFORM="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    PLATFORM="mac"
else
    echo "❌ Unsupported OS. Use Linux or macOS"
    exit 1
fi

# Create development directory
DEV_DIR="$HOME/android-dev"
mkdir -p $DEV_DIR
cd $DEV_DIR

echo "📁 Development directory: $DEV_DIR"

# 1. Install Java 11 (Required for Android Studio)
install_java() {
    echo "☕ Installing Java 11..."
    
    if command -v java &> /dev/null; then
        java_version=$(java -version 2>&1 | head -n1 | cut -d'"' -f2 | cut -d'.' -f1-2)
        if [[ "$java_version" == "11"* ]] || [[ "$java_version" == "17"* ]]; then
            echo "✅ Java already installed: $java_version"
            return 0
        fi
    fi
    
    if [[ "$PLATFORM" == "linux" ]]; then
        sudo apt update
        sudo apt install -y openjdk-11-jdk
    elif [[ "$PLATFORM" == "mac" ]]; then
        if command -v brew &> /dev/null; then
            brew install openjdk@11
        else
            echo "❌ Install Homebrew first: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
            exit 1
        fi
    fi
    
    echo "✅ Java 11 installed"
}

# 2. Download Android Studio
download_android_studio() {
    echo "📱 Downloading Android Studio..."
    
    if [[ "$PLATFORM" == "linux" ]]; then
        STUDIO_URL="https://redirector.gvt1.com/edgedl/android/studio/ide-zips/2023.1.1.28/android-studio-2023.1.1.28-linux.tar.gz"
        STUDIO_FILE="android-studio-linux.tar.gz"
    elif [[ "$PLATFORM" == "mac" ]]; then
        STUDIO_URL="https://redirector.gvt1.com/edgedl/android/studio/install/2023.1.1.28/android-studio-2023.1.1.28-mac.dmg"
        STUDIO_FILE="android-studio-mac.dmg"
    fi
    
    if [ ! -f "$STUDIO_FILE" ]; then
        echo "⬇️  Downloading Android Studio..."
        curl -L -o "$STUDIO_FILE" "$STUDIO_URL"
    else
        echo "✅ Android Studio already downloaded"
    fi
    
    # Extract Android Studio
    if [[ "$PLATFORM" == "linux" ]]; then
        if [ ! -d "android-studio" ]; then
            echo "📦 Extracting Android Studio..."
            tar -xzf "$STUDIO_FILE"
        fi
        STUDIO_PATH="$DEV_DIR/android-studio/bin/studio.sh"
    elif [[ "$PLATFORM" == "mac" ]]; then
        echo "📦 Please manually install the DMG file: $STUDIO_FILE"
        STUDIO_PATH="/Applications/Android Studio.app"
    fi
    
    echo "✅ Android Studio ready at: $STUDIO_PATH"
}

# 3. Setup Android SDK
setup_android_sdk() {
    echo "🔧 Setting up Android SDK..."
    
    # Set Android SDK path
    export ANDROID_HOME="$DEV_DIR/android-sdk"
    export PATH="$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools"
    
    # Create SDK directory
    mkdir -p "$ANDROID_HOME"
    
    # Download SDK command line tools
    SDK_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip"
    if [[ "$PLATFORM" == "mac" ]]; then
        SDK_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-mac-9477386_latest.zip"
    fi
    
    if [ ! -f "cmdline-tools.zip" ]; then
        echo "⬇️  Downloading SDK Command Line Tools..."
        curl -L -o "cmdline-tools.zip" "$SDK_TOOLS_URL"
    fi
    
    if [ ! -d "$ANDROID_HOME/cmdline-tools" ]; then
        echo "📦 Extracting SDK tools..."
        unzip -q cmdline-tools.zip -d "$ANDROID_HOME"
        mv "$ANDROID_HOME/cmdline-tools" "$ANDROID_HOME/cmdline-tools-temp"
        mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
        mv "$ANDROID_HOME/cmdline-tools-temp"/* "$ANDROID_HOME/cmdline-tools/latest/"
        rmdir "$ANDROID_HOME/cmdline-tools-temp"
    fi
    
    # Update PATH for SDK tools
    export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin"
    
    echo "✅ Android SDK tools installed"
}

# 4. Install required SDK packages
install_sdk_packages() {
    echo "📦 Installing required SDK packages..."
    
    # Accept licenses first
    yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses
    
    # Install required packages
    "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" \
        "platform-tools" \
        "platforms;android-24" \
        "platforms;android-33" \
        "build-tools;33.0.2" \
        "extras;android;m2repository" \
        "extras;google;m2repository"
    
    echo "✅ SDK packages installed"
}

# 5. Setup environment variables
setup_environment() {
    echo "🔧 Setting up environment variables..."
    
    # Create environment setup script
    cat > "$DEV_DIR/android-env.sh" << EOF
#!/bin/bash
# Android Development Environment
export ANDROID_HOME="$DEV_DIR/android-sdk"
export PATH="\$PATH:\$ANDROID_HOME/tools:\$ANDROID_HOME/platform-tools:\$ANDROID_HOME/cmdline-tools/latest/bin"
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk-amd64"

echo "✅ Android development environment loaded"
echo "📱 Android Studio: $STUDIO_PATH"
echo "🔧 Android SDK: \$ANDROID_HOME"
echo "☕ Java: \$JAVA_HOME"
EOF
    
    chmod +x "$DEV_DIR/android-env.sh"
    
    # Add to bashrc for permanent setup
    if ! grep -q "android-env.sh" ~/.bashrc; then
        echo "source $DEV_DIR/android-env.sh" >> ~/.bashrc
    fi
    
    echo "✅ Environment variables configured"
}

# 6. Verify installation
verify_installation() {
    echo "🔍 Verifying installation..."
    
    # Source environment
    source "$DEV_DIR/android-env.sh"
    
    # Check Java
    if command -v java &> /dev/null; then
        echo "✅ Java: $(java -version 2>&1 | head -n1)"
    else
        echo "❌ Java not found"
    fi
    
    # Check ADB
    if command -v adb &> /dev/null; then
        echo "✅ ADB: $(adb version | head -n1)"
    else
        echo "❌ ADB not found"
    fi
    
    # Check SDK
    if [ -d "$ANDROID_HOME" ]; then
        echo "✅ Android SDK: $ANDROID_HOME"
    else
        echo "❌ Android SDK not found"
    fi
    
    # Check Android Studio
    if [ -f "$STUDIO_PATH" ] || [ -d "$STUDIO_PATH" ]; then
        echo "✅ Android Studio: $STUDIO_PATH"
    else
        echo "❌ Android Studio not found"
    fi
}

# 7. Create project setup script
create_project_setup() {
    echo "📝 Creating project setup script..."
    
    cat > "$DEV_DIR/setup_hp_detector_project.sh" << 'EOF'
#!/bin/bash

echo "🚀 Setting up HP Finance Detector Project"

# Load Android environment
source ~/android-dev/android-env.sh

# Navigate to project directory
cd "/home/xtos/MI PROJEC/ultra/HPFinanceDetector"

# Create gradle wrapper if not exists
if [ ! -f "gradlew" ]; then
    echo "📦 Creating Gradle Wrapper..."
    gradle wrapper --gradle-version 8.0
fi

# Make gradlew executable
chmod +x gradlew

# Create local.properties with SDK path
echo "sdk.dir=$ANDROID_HOME" > local.properties

# Sync project
echo "🔄 Syncing Gradle project..."
./gradlew --version

echo "✅ Project setup complete!"
echo "🚀 Ready to build: ./gradlew assembleDebug"
EOF
    
    chmod +x "$DEV_DIR/setup_hp_detector_project.sh"
    
    echo "✅ Project setup script created: $DEV_DIR/setup_hp_detector_project.sh"
}

# Main installation process
main() {
    echo "🎯 Starting Android Development Environment Setup..."
    
    install_java
    download_android_studio
    setup_android_sdk
    install_sdk_packages
    setup_environment
    create_project_setup
    verify_installation
    
    echo ""
    echo "🎉 SETUP COMPLETE!"
    echo ""
    echo "📋 Next Steps:"
    echo "1. Restart terminal or run: source ~/android-dev/android-env.sh"
    echo "2. Start Android Studio: $STUDIO_PATH"
    echo "3. Setup HP Detector project: ~/android-dev/setup_hp_detector_project.sh"
    echo "4. Build APK: cd /home/xtos/MI\ PROJEC/ultra/HPFinanceDetector && ./gradlew assembleDebug"
    echo ""
    echo "🔧 Environment ready for HP Finance Detector development!"
}

# Run main installation
main