#!/bin/bash

echo "🚀 SIMPLE BUILD - DETEKTOR FINANCE"

# Install Java if not present
if ! command -v java &> /dev/null; then
    echo "☕ Installing Java..."
    sudo apt update
    sudo apt install -y openjdk-11-jdk
fi

# Create minimal Android SDK setup
ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME"

# Download command line tools if not exist
if [ ! -d "$ANDROID_HOME/cmdline-tools" ]; then
    echo "📦 Downloading Android SDK tools..."
    cd "$ANDROID_HOME"
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
    unzip -q commandlinetools-linux-*.zip
    mkdir -p cmdline-tools/latest
    mv cmdline-tools/* cmdline-tools/latest/ 2>/dev/null || true
    rm -f commandlinetools-linux-*.zip
fi

# Set environment
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

# Accept licenses and install required packages
echo "📋 Installing SDK packages..."
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses 2>/dev/null
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-33" "build-tools;33.0.2" 2>/dev/null

# Update local.properties
echo "sdk.dir=$ANDROID_HOME" > local.properties

# Go back to project directory
cd "/home/xtos/MI PROJEC/ultra/HPFinanceDetector"

# Fix gradlew
chmod +x gradlew

# Simple build
echo "🔨 Building APK..."
./gradlew assembleDebug --no-daemon --stacktrace

echo "✅ Build complete! Check app/build/outputs/apk/debug/ for APK file"