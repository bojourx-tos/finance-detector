#!/bin/bash

echo "🚀 QUICK BUILD - DETEKTOR FINANCE"

# Check if we're in the right directory
if [ ! -f "gradlew" ]; then
    echo "❌ Error: gradlew not found. Run from project root directory."
    exit 1
fi

# Make gradlew executable
chmod +x gradlew

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Check for Android SDK
if [ ! -d "/home/xtos/android-dev/android-sdk" ]; then
    echo "❌ Android SDK not found!"
    echo "Run: ./setup_dev_environment.sh first"
    exit 1
fi

# Set environment variables
export ANDROID_HOME="/home/xtos/android-dev/android-sdk"
export PATH="$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"

echo "🔧 Environment:"
echo "   ANDROID_HOME: $ANDROID_HOME"
echo "   Java: $(java -version 2>&1 | head -n1)"

# Build debug APK
echo "📱 Building debug APK..."
./gradlew assembleDebug

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "✅ BUILD SUCCESSFUL!"
    
    # Find the APK
    APK_PATH=$(find . -name "*.apk" -path "*/debug/*" | head -n1)
    
    if [ -n "$APK_PATH" ]; then
        echo "📱 APK Location: $APK_PATH"
        
        # Copy to easy access location
        cp "$APK_PATH" "./Detektor-Finance-Debug.apk"
        echo "📋 APK copied to: ./Detektor-Finance-Debug.apk"
        
        # Show APK info
        echo "📊 APK Info:"
        ls -lh Detektor-Finance-Debug.apk
        
        echo ""
        echo "🎯 READY TO TEST!"
        echo "Install: adb install Detektor-Finance-Debug.apk"
        echo "Or transfer to phone and install manually"
        
    else
        echo "❌ APK not found after build"
    fi
    
else
    echo "❌ BUILD FAILED!"
    echo "Check the error messages above"
    exit 1
fi